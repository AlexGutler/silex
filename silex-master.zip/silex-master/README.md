APIS E SILEX - Projeto Fase 1

Preparando o ambiente

O objetivo geral desse projeto ser� desenvolver uma API REST, utilizando inclusive banco de dados. Para isso ser� necess�rio termos uma estrutura b�sica necess�ria configurada para iniciarmos a cria��o das APIs.

Nessa fase do projeto, voc� instalar� o Silex e criar� 1 rotas principal, apenas para garantir que tudo est� configurado e funcionando.

1) Rota: /clientes

Com a rota /clientes, fa�a a simula��o da listagem de clientes com Nome, Email e CPF/CNPJ vindo de um array. O formato de exibi��o deve ser json.