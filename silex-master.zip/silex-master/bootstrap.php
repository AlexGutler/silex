<?php
require_once "vendor/autoload.php";

$app = new \Silex\Application();
$app['debug'] = true;